
#ifndef EEPROM_H
#define EEPROM_H

void readGlobalSet();
bool readEEPROM();
void LoadDefaults();




#endif  /* EEPROM */