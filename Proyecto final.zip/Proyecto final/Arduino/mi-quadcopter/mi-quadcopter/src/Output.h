
#ifndef OUTPUT_H
#define OUTPUT_H

void initOutput();
void writeMotors();

void mixTable();

#endif /* OUTPUT_H */