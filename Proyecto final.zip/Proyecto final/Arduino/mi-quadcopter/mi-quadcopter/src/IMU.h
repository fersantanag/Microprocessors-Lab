
#ifndef IMU_H
#define IMU_H

void computeIMU();
int32_t mul(int16_t a, int16_t b);


#endif /* IMU_H */