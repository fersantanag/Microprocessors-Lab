#include <Arduino.h>

#ifndef RECEIVER_H
#define RECEIVER_H

void initReceiver();
void initRX();
void computeRX();

#endif /* RECEIVER_H */
