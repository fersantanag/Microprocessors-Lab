/* 
 * File:   mainpruebaus.c
 * Author: fersg
 *
 * Created on 29 de abril de 2021, 16:47
 */

#include <stdio.h>
#include <stdlib.h>
#include "ultrasonidos.c"

/*
 * 
 */
int main(int argc, char** argv) {

    
    InicializarUltra();
    return ;
}

