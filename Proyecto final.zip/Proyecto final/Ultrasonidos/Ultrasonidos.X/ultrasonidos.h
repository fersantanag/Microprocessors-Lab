/**
 * @file ultrasonidos.h
 *
 * @author Fernando & Jorge
 */
// ------------------------------------------------------
#ifndef _ULTRASONIDOS_H
#define _ULTRASONIDOS_H

int InicializarUltra(void);
int getDistancia(void);
int getTicks(void);

#endif