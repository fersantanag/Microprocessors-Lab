

#ifndef RECEIVER_H
#define RECEIVER_H

void initReceiver();
void initRX();
void computeRX();
void sendString(char* s);

#endif /* RECEIVER_H */
