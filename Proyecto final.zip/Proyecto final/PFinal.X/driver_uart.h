/* 
 * File:   driver_uart.h
 * Author: Fernando & Jorge
 *
 * Created on 26 March 2021, 13:19
 */

#ifndef DRIVER_UART_H
#define	DRIVER_UART_H

void InicializarUART1(int baudios);
char getcUART();
void putsUART(char *ps);

#endif	/* DRIVER_UART_H */

