
#ifndef EEPROM_H
#define EEPROM_H

void readGlobalSet();
int readEEPROM();
void LoadDefaults();




#endif  /* EEPROM */
