

#ifndef RECEIVER_H
#define	RECEIVER_H



void initReceiver();
void computeRX();
void sendString(char* s);
void sendInfo();


#endif	/* RECEIVER_H */

